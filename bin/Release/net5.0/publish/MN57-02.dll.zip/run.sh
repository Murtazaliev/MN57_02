#!/bin/sh
cd /home/pi/mn57
./MN57-02
